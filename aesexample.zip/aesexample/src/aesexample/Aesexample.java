package aesexample;
import java.security.Key;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
public class Aesexample {
    private static final String ALGO="AES";
    private byte[] keyvalue;
    Aesexample(String key)
    {
        keyvalue=key.getBytes();
    }
    public String encrypt(String Data) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException
    {
        Key key=generateKey();
        Cipher c=Cipher.getInstance(ALGO);
        c.init(Cipher.ENCRYPT_MODE,key);
        byte[] encVal=c.doFinal(Data.getBytes());
        String encvalue;
        encvalue = new BASE64Encoder().encode(encVal);
        return encvalue;
    }
    public String decrypt(String encryptedData) throws Exception
    {
        Key key=generateKey();
        Cipher c=Cipher.getInstance(ALGO);
        c.init(Cipher.DECRYPT_MODE,key);
        byte[] decordedvalue = new BASE64Decoder().decodeBuffer(encryptedData);
        byte[] decValue=c.doFinal(decordedvalue);
        String decryptedValue=new String(decValue);
        return decryptedValue;
    }
    private Key generateKey() {
        Key key=new SecretKeySpec(keyvalue,ALGO);
        return key;
    }
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        Aesexample aes=new Aesexample("kdfgthyuilokjhgt");
        String encdata=aes.encrypt("Amarnath");
        System.out.println("Encrypt data= "+encdata);
        String decdata=aes.decrypt(encdata);
        System.out.println("decrypted data= "+decdata);
    }    
}
